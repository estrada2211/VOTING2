import { useState, useEffect } from "react";
import { supabase } from "./supabaseClient";

const AdminPanel = () => {
  const [candidates, setCandidates] = useState([]);
  const [name, setName] = useState("");
  const [yearLevel, setYearLevel] = useState("");
  const [position, setPosition] = useState("");
  const [image, setImage] = useState(null);
  const [message, setMessage] = useState("");

  useEffect(() => {
    fetchCandidates();
  }, []);

  const fetchCandidates = async () => {
    const { data, error } = await supabase.from("candidates").select("*");
    if (error) console.error("Error fetching candidates:", error);
    else setCandidates(data);
  };

  const handleAddCandidate = async (e) => {
    e.preventDefault();
    if (!name || !yearLevel || !position || !image) {
      setMessage("Please fill all fields and upload an image.");
      return;
    }
  
    try {
      // Generate unique filename
      const fileExt = image.name.split(".").pop();
      const fileName = `${Date.now()}.${fileExt}`;
      const filePath = `candidates/${fileName}`;
  
      // Upload Image to Supabase Storage
      const { data: uploadData, error: uploadError } = await supabase.storage
        .from("candidates") // <-- Ensure this is your bucket name
        .upload(filePath, image);
  
      if (uploadError) throw uploadError;
  
      // ✅ Get Public URL of the uploaded image
      const { data: publicUrlData } = supabase.storage
        .from("candidates")
        .getPublicUrl(filePath);
  
      if (!publicUrlData) throw new Error("Failed to get public URL");
  
      const imageUrl = publicUrlData.publicUrl; // ✅ Use this URL in database
  
      // Insert candidate into Supabase DB
      const { error: insertError } = await supabase.from("candidates").insert([
        { name, year_level: yearLevel, position, photo_url: imageUrl },
      ]);
  
      if (insertError) throw insertError;
  
      setMessage("Candidate added successfully!");
      fetchCandidates(); // Refresh the list
      setName("");
      setYearLevel("");
      setPosition("");
      setImage(null);
    } catch (error) {
      console.error("Error:", error.message);
      setMessage("Error uploading image. Check console for details.");
    }
  };

  return (
    <div>
      <h2>Admin Panel - Add Candidates</h2>
      <form onSubmit={handleAddCandidate}>
        <input type="text" placeholder="Name" value={name} onChange={(e) => setName(e.target.value)} required />
        <input type="text" placeholder="Year Level" value={yearLevel} onChange={(e) => setYearLevel(e.target.value)} required />
        <input type="text" placeholder="Position" value={position} onChange={(e) => setPosition(e.target.value)} required />
        <input type="file" accept="image/*" onChange={(e) => setImage(e.target.files[0])} required />
        <button type="submit">Add Candidate</button>
      </form>
      <p>{message}</p>

      <h3>Candidate List</h3>
      <ul>
        {candidates.map((candidate) => (
          <li key={candidate.id}>
            <img src={candidate.photo_url} alt={candidate.name} width="50" />
            {candidate.name} - {candidate.year_level} - {candidate.position}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default AdminPanel;
