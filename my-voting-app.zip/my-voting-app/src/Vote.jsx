import { useEffect, useState } from "react";
import { supabase } from "./supabaseClient";

const Vote = () => {
  const [candidates, setCandidates] = useState([]);
  const [selectedCandidates, setSelectedCandidates] = useState({});
  const [message, setMessage] = useState("");

  useEffect(() => {
    fetchCandidates();
  }, []);

  const fetchCandidates = async () => {
    const { data, error } = await supabase.from("candidates").select("*");

    if (error) {
      console.error("Error fetching candidates:", error);
    } else {
      console.log("Candidates fetched:", data); // Debugging
      setCandidates(data);
    }
  };

  const handleSelectCandidate = (position, candidateId) => {
    setSelectedCandidates((prev) => ({ ...prev, [position]: candidateId }));
  };

  const handleSubmitVote = async () => {
    const { data: user, error: authError } = await supabase.auth.getUser();
    const userId = user?.user?.id;

    if (!userId) {
      setMessage("You must be logged in to vote.");
      return;
    }

    const votesToSubmit = Object.entries(selectedCandidates).map(([position, candidateId]) => ({
      user_id: userId,
      candidates_id: candidateId,
      position,
    }));

    const { error } = await supabase.from("votes").insert(votesToSubmit);

    if (error) {
      setMessage("Error submitting vote. You may have already voted.");
      console.error(error);
    } else {
      setMessage("Vote submitted successfully!");
    }
  };

  // ✅ Fix reduce() issue
  const groupedCandidates = candidates.reduce((acc, candidate) => {
    acc[candidate.position] = acc[candidate.position] || [];
    acc[candidate.position].push(candidate);
    return acc;
  }, {});

  return (
    <div>
      <h2>Vote for Your Candidates</h2>
      {candidates.length === 0 ? (
        <p>Loading candidates...</p>
      ) : (
        <div>
          {Object.entries(groupedCandidates).map(([position, candidates]) => (
            <div key={position}>
              <h3>{position}</h3>
              {candidates.map((candidate) => (
                <label key={candidate.id} style={{ display: "block" }}>
                  <input
                    type="radio"
                    name={position}
                    value={candidate.id}
                    onChange={() => handleSelectCandidate(position, candidate.id)}
                  />
                  {candidate.name}
                  <img src={candidate.photo_url} alt={candidate.name} width="50" style={{ marginLeft: "10px" }} />
                </label>
              ))}
            </div>
          ))}
        </div>
      )}
      <button onClick={handleSubmitVote} disabled={Object.keys(selectedCandidates).length === 0}>
        Submit Vote
      </button>
      <p>{message}</p>
    </div>
  );
};

export default Vote;
